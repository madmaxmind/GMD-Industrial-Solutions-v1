# GMD Industrial Solutions

Sitio web optimizado para el sector industrial, listo para publicar en GitHub Pages.

## Instrucciones rápidas
1. Clona el repositorio y sube los archivos.
2. Activa GitHub Pages desde la rama `main`.
3. Crea tu Google Sheet público y actualiza el ID en `blog.js`.
4. Coloca tus artículos en formato Markdown.

## Contacto
📧 gmdmechanicaldesign@gmail.com
📞 +52 444 414 8560
📍 San Luis Potosí, México
